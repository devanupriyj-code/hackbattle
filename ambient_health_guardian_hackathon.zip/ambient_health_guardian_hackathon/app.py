#!/usr/bin/env python3
"""
The Ambient Health Guardian - Complete Hackathon Implementation
Contactless Health Monitoring System using FMCW Radar and AI
"""

import os
import json
import time
import threading
import numpy as np
from datetime import datetime
import sqlite3
from dataclasses import dataclass
from typing import Dict, List, Optional
import logging
from flask import Flask, render_template, jsonify, request, send_file

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class VitalSigns:
    timestamp: datetime
    heart_rate: float
    respiratory_rate: float
    body_temperature: float
    stress_level: float
    activity_level: str
    alert_status: str

@dataclass
class EnvironmentalData:
    timestamp: datetime
    room_temperature: float
    humidity: float
    air_quality_index: int
    light_level: float
    noise_level: float

class DatabaseManager:
    def __init__(self, db_path: str = "health_data.db"):
        self.db_path = db_path
        self.init_database()

    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vital_signs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                heart_rate REAL,
                respiratory_rate REAL,
                body_temperature REAL,
                stress_level REAL,
                activity_level TEXT,
                alert_status TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS environmental_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                room_temperature REAL,
                humidity REAL,
                air_quality_index INTEGER,
                light_level REAL,
                noise_level REAL
            )
        """)

        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")

    def store_vital_signs(self, data: VitalSigns):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO vital_signs 
            (timestamp, heart_rate, respiratory_rate, body_temperature, 
             stress_level, activity_level, alert_status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            data.timestamp.isoformat(),
            data.heart_rate,
            data.respiratory_rate,
            data.body_temperature,
            data.stress_level,
            data.activity_level,
            data.alert_status
        ))

        conn.commit()
        conn.close()

    def get_recent_data(self, hours: int = 24) -> List[Dict]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute(f"""
            SELECT * FROM vital_signs 
            WHERE timestamp > datetime('now', '-{hours} hours')
            ORDER BY timestamp DESC
        """)

        columns = [description[0] for description in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]

        conn.close()
        return results

class SensorSimulator:
    def __init__(self):
        self.base_heart_rate = 72
        self.base_resp_rate = 16
        self.base_temperature = 98.6

    def get_fmcw_radar_data(self) -> Dict[str, float]:
        time_factor = time.time() % 60
        noise = np.random.normal(0, 2)

        heart_rate = self.base_heart_rate + noise + 5 * np.sin(time_factor / 10)
        heart_rate = max(60, min(100, heart_rate))

        resp_noise = np.random.normal(0, 1)
        respiratory_rate = self.base_resp_rate + resp_noise + 2 * np.sin(time_factor / 15)
        respiratory_rate = max(12, min(20, respiratory_rate))

        return {
            'heart_rate': round(heart_rate, 1),
            'respiratory_rate': round(respiratory_rate, 1),
            'signal_quality': np.random.uniform(0.8, 1.0)
        }

    def get_thermal_data(self) -> Dict[str, float]:
        temp_variation = np.random.normal(0, 0.3)
        body_temp = self.base_temperature + temp_variation

        return {
            'body_temperature': round(body_temp, 1),
            'thermal_comfort': np.random.uniform(0.7, 0.9)
        }

    def get_environmental_data(self) -> EnvironmentalData:
        return EnvironmentalData(
            timestamp=datetime.now(),
            room_temperature=round(np.random.normal(72, 3), 1),
            humidity=round(np.random.normal(45, 10), 1),
            air_quality_index=int(np.random.normal(50, 15)),
            light_level=round(np.random.uniform(100, 800), 1),
            noise_level=round(np.random.normal(40, 10), 1)
        )

class HealthAnalyzer:
    def __init__(self):
        self.alert_thresholds = {
            'heart_rate_low': 60, 'heart_rate_high': 100,
            'respiratory_rate_low': 12, 'respiratory_rate_high': 20,
            'temperature_low': 97.0, 'temperature_high': 99.5
        }

    def analyze_vital_signs(self, heart_rate: float, resp_rate: float, body_temp: float) -> Dict:
        alerts = []
        stress_indicators = 0

        if heart_rate < self.alert_thresholds['heart_rate_low']:
            alerts.append("Low heart rate detected")
            stress_indicators += 1
        elif heart_rate > self.alert_thresholds['heart_rate_high']:
            alerts.append("Elevated heart rate detected")
            stress_indicators += 2

        if resp_rate < self.alert_thresholds['respiratory_rate_low']:
            alerts.append("Low respiratory rate")
            stress_indicators += 1
        elif resp_rate > self.alert_thresholds['respiratory_rate_high']:
            alerts.append("Elevated respiratory rate")
            stress_indicators += 2

        if body_temp < self.alert_thresholds['temperature_low']:
            alerts.append("Low body temperature")
            stress_indicators += 1
        elif body_temp > self.alert_thresholds['temperature_high']:
            alerts.append("Elevated temperature - possible fever")
            stress_indicators += 3

        stress_level = min(1.0, stress_indicators / 5.0)

        if heart_rate > 90:
            activity_level = "High"
        elif heart_rate > 75:
            activity_level = "Moderate"
        else:
            activity_level = "Resting"

        if stress_indicators >= 3:
            alert_status = "Critical"
        elif stress_indicators >= 1:
            alert_status = "Warning"
        else:
            alert_status = "Normal"

        recommendations = []
        if stress_level > 0.5:
            recommendations.extend(["Practice deep breathing", "Stay hydrated"])
        if activity_level == "High":
            recommendations.extend(["Monitor exertion", "Take breaks"])
        if not recommendations:
            recommendations.extend(["Maintain healthy lifestyle", "Continue monitoring"])

        return {
            'stress_level': stress_level,
            'activity_level': activity_level,
            'alert_status': alert_status,
            'alerts': alerts,
            'recommendations': recommendations
        }

class AmbientHealthGuardian:
    def __init__(self):
        self.db_manager = DatabaseManager()
        self.sensor_simulator = SensorSimulator()
        self.health_analyzer = HealthAnalyzer()
        self.is_monitoring = False
        self.monitoring_thread = None
        logger.info("Ambient Health Guardian initialized")

    def start_monitoring(self):
        if not self.is_monitoring:
            self.is_monitoring = True
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop)
            self.monitoring_thread.daemon = True
            self.monitoring_thread.start()
            logger.info("Health monitoring started")
            return True
        return False

    def stop_monitoring(self):
        self.is_monitoring = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        logger.info("Health monitoring stopped")
        return True

    def _monitoring_loop(self):
        while self.is_monitoring:
            try:
                radar_data = self.sensor_simulator.get_fmcw_radar_data()
                thermal_data = self.sensor_simulator.get_thermal_data()

                analysis = self.health_analyzer.analyze_vital_signs(
                    radar_data['heart_rate'],
                    radar_data['respiratory_rate'],
                    thermal_data['body_temperature']
                )

                vital_signs = VitalSigns(
                    timestamp=datetime.now(),
                    heart_rate=radar_data['heart_rate'],
                    respiratory_rate=radar_data['respiratory_rate'],
                    body_temperature=thermal_data['body_temperature'],
                    stress_level=analysis['stress_level'],
                    activity_level=analysis['activity_level'],
                    alert_status=analysis['alert_status']
                )

                self.db_manager.store_vital_signs(vital_signs)

                logger.info(f"Status: {analysis['alert_status']} | HR: {radar_data['heart_rate']} | Temp: {thermal_data['body_temperature']}°F")
                time.sleep(10)

            except Exception as e:
                logger.error(f"Error in monitoring: {e}")
                time.sleep(5)

    def get_current_status(self) -> Dict:
        recent_data = self.db_manager.get_recent_data(hours=1)

        if not recent_data:
            return {"status": "No recent data", "monitoring": self.is_monitoring}

        latest = recent_data[0]

        # Get fresh environmental data
        env_data = self.sensor_simulator.get_environmental_data()

        # Get recommendations
        vs = latest
        analysis = self.health_analyzer.analyze_vital_signs(
            vs['heart_rate'], vs['respiratory_rate'], vs['body_temperature']
        )

        return {
            'timestamp': latest['timestamp'],
            'monitoring_active': self.is_monitoring,
            'vital_signs': {
                'heart_rate': latest['heart_rate'],
                'respiratory_rate': latest['respiratory_rate'],
                'body_temperature': latest['body_temperature'],
                'stress_level': latest['stress_level']
            },
            'status': latest['alert_status'],
            'activity_level': latest['activity_level'],
            'environmental': {
                'room_temperature': env_data.room_temperature,
                'humidity': env_data.humidity,
                'air_quality': env_data.air_quality_index,
                'light_level': env_data.light_level,
                'noise_level': env_data.noise_level
            },
            'recommendations': analysis['recommendations'],
            'data_points': len(recent_data)
        }

# Flask Application
app = Flask(__name__)
health_guardian = AmbientHealthGuardian()

@app.route('/')
def dashboard():
    return send_file('templates/index.html')

@app.route('/api/status')
def get_status():
    try:
        status = health_guardian.get_current_status()
        return jsonify(status)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/start', methods=['POST'])
def start_monitoring():
    try:
        success = health_guardian.start_monitoring()
        return jsonify({"success": success, "message": "Monitoring started" if success else "Already monitoring"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/stop', methods=['POST'])
def stop_monitoring():
    try:
        success = health_guardian.stop_monitoring()
        return jsonify({"success": success, "message": "Monitoring stopped"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/data')
def get_historical_data():
    try:
        hours = request.args.get('hours', 1, type=int)
        data = health_guardian.db_manager.get_recent_data(hours=hours)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print("🚀 Starting Ambient Health Guardian...")
    print("🌐 Dashboard: http://localhost:5000")
    print("📊 Features: Contactless monitoring, AI analysis, Real-time alerts")
    print("="*60)

    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
