#!/bin/bash
echo "🚀 Starting Ambient Health Guardian..."
echo ""
pip install -r requirements.txt
echo ""
echo "🌐 Starting web server..."
echo "Dashboard will be available at: http://localhost:5000"
echo ""
python app.py
